<?php
require_once("DB.php");

?>