<?php

/* base.html.twig */
class __TwigTemplate_dba0515cc29dc68bf37eeb4db84f370c86ef54c19d4e257da82bb34f37a1c7b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c1d0680c4c114ef4c2c8573972a592ac9abcacc5b391927d22b2d5302461298 = $this->env->getExtension("native_profiler");
        $__internal_5c1d0680c4c114ef4c2c8573972a592ac9abcacc5b391927d22b2d5302461298->enter($__internal_5c1d0680c4c114ef4c2c8573972a592ac9abcacc5b391927d22b2d5302461298_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_5c1d0680c4c114ef4c2c8573972a592ac9abcacc5b391927d22b2d5302461298->leave($__internal_5c1d0680c4c114ef4c2c8573972a592ac9abcacc5b391927d22b2d5302461298_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_2582065a68244ec8dc8bbf2356fd6a89f30bfef6786d6a0a301cb8c21c052683 = $this->env->getExtension("native_profiler");
        $__internal_2582065a68244ec8dc8bbf2356fd6a89f30bfef6786d6a0a301cb8c21c052683->enter($__internal_2582065a68244ec8dc8bbf2356fd6a89f30bfef6786d6a0a301cb8c21c052683_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_2582065a68244ec8dc8bbf2356fd6a89f30bfef6786d6a0a301cb8c21c052683->leave($__internal_2582065a68244ec8dc8bbf2356fd6a89f30bfef6786d6a0a301cb8c21c052683_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_4dd965b37e2adca7706d6636ce67c341051612cd2ce25cec60cd594cc6398455 = $this->env->getExtension("native_profiler");
        $__internal_4dd965b37e2adca7706d6636ce67c341051612cd2ce25cec60cd594cc6398455->enter($__internal_4dd965b37e2adca7706d6636ce67c341051612cd2ce25cec60cd594cc6398455_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_4dd965b37e2adca7706d6636ce67c341051612cd2ce25cec60cd594cc6398455->leave($__internal_4dd965b37e2adca7706d6636ce67c341051612cd2ce25cec60cd594cc6398455_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_7c4d5417393c54d7037ffb43384993265265e93264ea672781f7455ef60dbe17 = $this->env->getExtension("native_profiler");
        $__internal_7c4d5417393c54d7037ffb43384993265265e93264ea672781f7455ef60dbe17->enter($__internal_7c4d5417393c54d7037ffb43384993265265e93264ea672781f7455ef60dbe17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_7c4d5417393c54d7037ffb43384993265265e93264ea672781f7455ef60dbe17->leave($__internal_7c4d5417393c54d7037ffb43384993265265e93264ea672781f7455ef60dbe17_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_31b1f482a008394dcbb44942233fba0442e48d31e97ea297cf432e65103ec9eb = $this->env->getExtension("native_profiler");
        $__internal_31b1f482a008394dcbb44942233fba0442e48d31e97ea297cf432e65103ec9eb->enter($__internal_31b1f482a008394dcbb44942233fba0442e48d31e97ea297cf432e65103ec9eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_31b1f482a008394dcbb44942233fba0442e48d31e97ea297cf432e65103ec9eb->leave($__internal_31b1f482a008394dcbb44942233fba0442e48d31e97ea297cf432e65103ec9eb_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
